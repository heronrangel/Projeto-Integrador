import tkinter as tk
from PIL import Image, ImageTk
import customtkinter as ctk

# janela principal
janela = tk.Tk()
janela.title("Lavanderia Campo Grande")
janela.geometry("1080x1080")
janela.configure(bg="#ffffff")

#-------------------------
# INICIAL

# Header com logo
frame_topo = ctk.CTkFrame(janela, fg_color="#ffffff")
frame_topo.pack(fill="x")

img_logo = Image.open("logo.png")
img_logo = img_logo.resize((250,210))

logo_img = ImageTk.PhotoImage(img_logo)

logo = tk.Label(
    frame_topo,
    image=logo_img,
    bg="#ffffff",
    cursor="hand2"
)
logo.pack(pady=10)

# Função para trocar de telas
def mostrar_frame(frame):
    for widget in frame_conteudo.winfo_children():
        widget.pack_forget()

    frame.pack(fill="both", expand=True)

# Área inicial de conteúdo
frame_conteudo = ctk.CTkFrame(janela)
frame_conteudo.pack(fill="both", expand=True)

frame_inicio = ctk.CTkFrame(frame_conteudo, width=250, height=200)

# Botões menu inicial
cor_botao = "#406E94"

def criar_botao(texto, clicar):
    return ctk.CTkButton(
        frame_inicio,
        width=200,
        height=40,
        text=texto,
        font=("Arial", 16),
        fg_color=cor_botao,
        corner_radius=20,
        text_color="#ffffff",
        hover_color="#215396",
        command=clicar
    )

botao_clientes = criar_botao("Pedidos", lambda: mostrar_frame(frame_pedidos))
botao_clientes.pack(pady=15)

botao_produtos = criar_botao("Produtos", lambda: mostrar_frame(frame_produtos))
botao_produtos.pack(pady=15)

botao_inicio = criar_botao("Controle", lambda: mostrar_frame(frame_controle))
botao_inicio.pack(pady=15)

# Logo linkado para o início
logo.bind("<Button-1>", lambda e: mostrar_frame(frame_inicio))
mostrar_frame(frame_inicio)

#------------------------
# TELA DE PEDIDOS
frame_pedidos = ctk.CTkFrame(frame_conteudo)

titulo_pedidos = ctk.CTkLabel(
    frame_pedidos,
    text="Pedidos",
    font=("Arial", 25),
    text_color="#215396"
)
titulo_pedidos.pack(pady=20)

# Campo Serviço
campo_servico = ctk.CTkEntry(
    frame_pedidos,
    placeholder_text="Nome do Serviço",
    width=300
)
campo_servico.pack(pady=10)

# Lista de itens (simulação backend)
lista_itens_backend = [
    "Camisa",
    "Calça",
    "Cobertor",
    "Edredom"
]

# Lista + botão para adicionar itens
frame_itens = ctk.CTkFrame(frame_pedidos)
frame_itens.pack(pady=10)

campo_itens = ctk.CTkComboBox(
    frame_itens,
    values=lista_itens_backend,
    width=200
)
campo_itens.pack(side="left", padx=5)

itens_adicionados = []

lista_pedido = tk.Listbox(
    frame_pedidos,
    width=40,
    height=8
)

lista_pedido.pack(pady=10)

# simulação de preços (depois vem do backend)
precos = {
    "Camisa": 10,
    "Calça": 12,
    "Cobertor": 25,
    "Edredom": 35
    }

# Função para adicionar item ao pedido (simulação de backend)
def adicionar_item():

    global valor_total

    item = campo_itens.get()

    if item == "":
        return

    preco = precos.get(item, 0)
    itens_adicionados.append(item)
    lista_pedido.insert(tk.END, f"{item} - R$ {preco}")
    valor_total = valor_total + preco
    label_total.configure(text=f"Total: R$ {valor_total:.2f}")

# Botão para adicionar item
botao_adicionar = ctk.CTkButton(
    frame_itens,
    text="Adicionar",
    width=120,
    height=35,
    command=adicionar_item
)

botao_adicionar.pack(side="left", padx=5)

# Remover item
def remover_item():
    global valor_total

    selecionado = lista_pedido.curselection()

    if not selecionado:
        return

    indice = selecionado[0]
    item = itens_adicionados[indice]
    preco = precos.get(item, 0)
    valor_total -= preco
    lista_pedido.delete(indice)
    itens_adicionados.pop(indice)
    
    label_total.configure(text=f"Total: R$ {valor_total:.2f}")

lista_pedido.bind("<Double-Button-1>", lambda e: remover_item())

# Total (ver backend)
valor_total = 0
label_total = ctk.CTkLabel(
    frame_pedidos,
    text="Total: R$ 0.00",
    font=("Arial", 18)
)
label_total.configure(text=f"Total: R$ {valor_total}")
label_total.pack(pady=10)

# Salvar o pedido (simulação de backend)
def salvar_pedido():
    servico = campo_servico.get()
    print("Serviço:", servico)
    print("Itens:", itens_adicionados)
    print("Total:", valor_total)

botao_salvar = ctk.CTkButton(
    frame_pedidos,
    text="Salvar Pedido",
    width=200,
    height=40,
    font=("Arial", 16),
    corner_radius=20,
    text_color="#ffffff",
    hover_color="#215396",
    command=salvar_pedido
)

botao_salvar.pack(pady=20)

# ------------------------
# TELA PRODUTOS
frame_produtos = ctk.CTkFrame(frame_conteudo)

titulo_produtos = ctk.CTkLabel(
    frame_produtos,
    text="Cadastro de Produto",
    font=("Arial", 25),
    text_color="#215396"
)
titulo_produtos.pack(pady=20)

frame_produto = ctk.CTkFrame(frame_produtos, fg_color="transparent")
frame_produto.pack(pady=10)

# Nome do Produto
label_nome_produto = ctk.CTkLabel(
    frame_produto,
    text="Nome do Produto",
    anchor="w",
    width=400
)
label_nome_produto.grid(row=0, column=0, sticky="ew", pady=(0,0))

campo_nome_produto = ctk.CTkEntry(
    frame_produto,
    width=350
)
campo_nome_produto.grid(row=1, column=0, padx=10, pady=5)

# Valor do Produto
label_nome_produto = ctk.CTkLabel(
    frame_produto,
    text="Nome do Produto",
    anchor="w",
    width=400
)
label_nome_produto.grid(row=0, column=0, sticky="ew", pady=(10,0))


campo_nome_produto = ctk.CTkEntry(
    frame_produto,
    width=400
)
campo_nome_produto.grid(row=1, column=0, sticky="ew", pady=5)
label_valor_produto = ctk.CTkLabel(
    frame_produto,
    text="Valor do Produto",
    anchor="w",
    width=400
)
label_valor_produto.grid(row=2, column=0, sticky="ew", pady=(10,0))

campo_valor_produto = ctk.CTkEntry(
    frame_produto,
    width=200
)
campo_valor_produto.grid(row=3, column=0, sticky="w", pady=5)

# Unidade de Medida
label_unidade = ctk.CTkLabel(
    frame_produto,
    text="Unidade de Medida",
    anchor="w",
    width=400
)
label_unidade.grid(row=4, column=0, sticky="ew", pady=(10,0))

combo_unidade = ctk.CTkComboBox(
    frame_produto,
    values=["UNIDADE", "KG", "LITRO"],
    width=200
)
combo_unidade.grid(row=5, column=0, sticky="w", pady=5)

# Estoque
label_estoque = ctk.CTkLabel(
    frame_produto,
    text="Estoque",
    anchor="w",
    width=400
)
label_estoque.grid(row=6, column=0, sticky="ew", pady=(10,0))

campo_estoque = ctk.CTkEntry(
    frame_produto,
    width=200
)
campo_estoque.grid(row=7, column=0, sticky="w", pady=5)

# Botão Gravar
def gravar_produto():
    print("Produto gravado")
botao_gravar = ctk.CTkButton(
    frame_produtos,
    text="Gravar",
    width=200,
    height=40,
    font=("Arial", 16),
    corner_radius=20,
    text_color="#ffffff",
    hover_color="#215396",
    command=gravar_produto
)
botao_gravar.pack(pady=10)

#------------------------
# Tela CONTROLE (FALTA BACKEND)
frame_controle = ctk.CTkFrame(frame_conteudo)

titulo_controle = ctk.CTkLabel(
    frame_controle,
    text="Controle",
    font=("Arial", 25),
    text_color="#215396"
)

titulo_controle.pack(pady=20)

janela.mainloop()